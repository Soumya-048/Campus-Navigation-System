import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class CampusNavigatingSystem
 {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/campus1";
    private static final String USER = "root";
    private static final String PASS = "your_password";

    private JFrame frame;
    private JComboBox<String> tableComboBox;
    private JTextField[] textFields;
    private JTextArea outputArea;
    private JTextField searchField;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                CampusNavigatingSystemApp app = new CampusNavigatingSystemApp();
                app.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public CampusNavigatingSystemApp() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Campus Navigating System App");
        frame.setBounds(100, 100, 600, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        frame.getContentPane().add(panel, BorderLayout.NORTH);

        JLabel lblTable = new JLabel("Select Table:");
        panel.add(lblTable);

        String[] tables = {"Buildings", "Departments", "Facilities", "POIs", "Paths", "Users", "Events"};
        tableComboBox = new JComboBox<>(tables);
        panel.add(tableComboBox);

        JButton btnAdd = new JButton("Add");
        panel.add(btnAdd);

        JButton btnUpdate = new JButton("Update");
        panel.add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        panel.add(btnDelete);

        JLabel lblSearch = new JLabel("Search:");
        panel.add(lblSearch);

        searchField = new JTextField(10);
        panel.add(searchField);

        JButton btnSearch = new JButton("Search");
        panel.add(btnSearch);

        JButton btnViewAll = new JButton("View All");
        panel.add(btnViewAll);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel();
        frame.getContentPane().add(inputPanel, BorderLayout.SOUTH);
        inputPanel.setLayout(new GridLayout(0, 2, 10, 10));

        textFields = new JTextField[8];
        for (int i = 0; i < textFields.length; i++) {
            textFields[i] = new JTextField();
            inputPanel.add(new JLabel("Field " + (i + 1) + ":"));
            inputPanel.add(textFields[i]);
        }

        btnAdd.addActionListener(e -> addRecord());
        btnUpdate.addActionListener(e -> updateRecord());
        btnDelete.addActionListener(e -> deleteRecord());
        btnSearch.addActionListener(e -> searchRecord());
        btnViewAll.addActionListener(e -> viewAllRecords());
    }

    private void addRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "INSERT INTO Buildings (BuildingID, Name, LocationLat, LocationLong, Address, Floors) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setInt(6, Integer.parseInt(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "INSERT INTO Departments (DepartmentID, Name, BuildingID, ContactInfo, Head) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setInt(3, Integer.parseInt(textFields[2].getText()));
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "INSERT INTO Facilities (FacilityID, Name, LocationLat, LocationLong, Description, Type) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setString(6, textFields[5].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "INSERT INTO POIs (POIID, Name, LocationLat, LocationLong, Description) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "INSERT INTO Paths (PathID, StartLocationLat, StartLocationLong, EndLocationLat, EndLocationLong, Distance, Time, Description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setFloat(2, Float.parseFloat(textFields[1].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(7, Integer.parseInt(textFields[6].getText()));
                        pstmt.setString(8, textFields[7].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "INSERT INTO Users (UserID, Name, Email, Role, LastKnownLocationLat, LastKnownLocationLong) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "INSERT INTO Events (EventID, Title, Description, Location, EventDate, EventTime, Organizer) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setInt(4, Integer.parseInt(textFields[3].getText()));
                        pstmt.setDate(5, Date.valueOf(textFields[4].getText()));
                        pstmt.setTime(6, Time.valueOf(textFields[5].getText()));
                        pstmt.setString(7, textFields[6].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            JOptionPane.showMessageDialog(frame, "Record added successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding record: " + ex.getMessage());
        }
    }

    private void updateRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "UPDATE Buildings SET Name = ?, LocationLat = ?, LocationLong = ?, Address = ?, Floors = ? WHERE BuildingID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "UPDATE Departments SET Name = ?, BuildingID = ?, ContactInfo = ?, Head = ? WHERE DepartmentID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setInt(2, Integer.parseInt(textFields[2].getText()));
                        pstmt.setString(3, textFields[3].getText());
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "UPDATE Facilities SET Name = ?, LocationLat = ?, LocationLong = ?, Description = ?, Type = ? WHERE FacilityID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setString(5, textFields[5].getText());
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "UPDATE POIs SET Name = ?, LocationLat = ?, LocationLong = ?, Description = ? WHERE POIID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "UPDATE Paths SET StartLocationLat = ?, StartLocationLong = ?, EndLocationLat = ?, EndLocationLong = ?, Distance = ?, Time = ?, Description = ? WHERE PathID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setFloat(1, Float.parseFloat(textFields[1].getText()));
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[6].getText()));
                        pstmt.setString(7, textFields[7].getText());
                        pstmt.setInt(8, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "UPDATE Users SET Name = ?, Email = ?, Role = ?, LastKnownLocationLat = ?, LastKnownLocationLong = ? WHERE UserID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setString(2, textFields[2].getText());
                        pstmt.setString(3, textFields[3].getText());
                        pstmt.setFloat(4, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "UPDATE Events SET Title = ?, Description = ?, Location = ?, EventDate = ?, EventTime = ?, Organizer = ? WHERE EventID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setString(2, textFields[2].getText());
                        pstmt.setInt(3, Integer.parseInt(textFields[3].getText()));
                        pstmt.setDate(4, Date.valueOf(textFields[4].getText()));
                        pstmt.setTime(5, Time.valueOf(textFields[5].getText()));
                        pstmt.setString(6, textFields[6].getText());
                        pstmt.setInt(7, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            JOptionPane.showMessageDialog(frame, "Record updated successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error updating record: " + ex.getMessage());
        }
    }

    private void deleteRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "DELETE FROM Buildings WHERE BuildingID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "DELETE FROM Departments WHERE DepartmentID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "DELETE FROM Facilities WHERE FacilityID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "DELETE FROM POIs WHERE POIID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql))
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "DELETE FROM Paths WHERE PathID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "DELETE FROM Users WHERE UserID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "DELETE FROM Events WHERE EventID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            JOptionPane.showMessageDialog(frame, "Record deleted successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error deleting record: " + ex.getMessage());
        }
    }

    private void searchRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String searchText = searchField.getText();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "SELECT * FROM Buildings WHERE BuildingID = ? OR Name = ?";
                    break;
                case "Departments":
                    sql = "SELECT * FROM Departments WHERE DepartmentID = ? OR Name = ?";
                    break;
                case "Facilities":
                    sql = "SELECT * FROM Facilities WHERE FacilityID = ? OR Name = ?";
                    break;
                case "POIs":
                    sql = "SELECT * FROM POIs WHERE POIID = ? OR Name = ?";
                    break;
                case "Paths":
                    sql = "SELECT * FROM Paths WHERE PathID = ?";
                    break;
                case "Users":
                    sql = "SELECT * FROM Users WHERE UserID = ? OR Name = ?";
                    break;
                case "Events":
                    sql = "SELECT * FROM Events WHERE EventID = ? OR Title = ?";
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                if (selectedTable.equals("Paths")) {
                    pstmt.setInt(1, Integer.parseInt(searchText));
                } else {
                    pstmt.setInt(1, Integer.parseInt(searchText));
                    pstmt.setString(2, searchText);
                }
                ResultSet rs = pstmt.executeQuery();
                outputArea.setText("");
                while (rs.next()) {
                    for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                        outputArea.append(rs.getMetaData().getColumnName(i) + ": " + rs.getString(i) + "\n");
                    }
                    outputArea.append("\n");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error searching record: " + ex.getMessage());
        }
    }

    private void viewAllRecords() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "SELECT * FROM " + selectedTable;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            outputArea.setText("");
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    outputArea.append(rs.getMetaData().getColumnName(i) + ": " + rs.getString(i) + "\n");
                }
                outputArea.append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error viewing records: " + ex.getMessage());
        }
    }
}

