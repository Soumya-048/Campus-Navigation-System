import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class CampusNavigatingSystemApp {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/campus1";
    private static final String USER = "root"; // Change to your database username
    private static final String PASS = "Soumya@1411"; // Change to your database password

    private JFrame frame;
    private JTextField[] textFields;
    private JComboBox<String> tableComboBox;
    private JLabel[] labels;

    private static final String[] TABLES = {
            "Buildings", "Departments", "Facilities", "POIs", "Paths", "Users", "Events"
    };

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                CampusNavigatingSystemApp window = new CampusNavigatingSystemApp();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public CampusNavigatingSystemApp() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        tableComboBox = new JComboBox<>(TABLES);
        tableComboBox.setBounds(20, 20, 200, 25);
        frame.getContentPane().add(tableComboBox);

        JButton btnLoadTable = new JButton("Load Table");
        btnLoadTable.setBounds(240, 20, 100, 25);
        frame.getContentPane().add(btnLoadTable);
        btnLoadTable.addActionListener(e -> loadTableFields());

        labels = new JLabel[6];
        textFields = new JTextField[6];
        for (int i = 0; i < 6; i++) {
            labels[i] = new JLabel();
            labels[i].setBounds(20, 60 + i * 30, 100, 25);
            frame.getContentPane().add(labels[i]);

            textFields[i] = new JTextField();
            textFields[i].setBounds(140, 60 + i * 30, 200, 25);
            frame.getContentPane().add(textFields[i]);
        }

        JButton btnAdd = new JButton("Add");
        btnAdd.setBounds(20, 280, 80, 25);
        frame.getContentPane().add(btnAdd);
        btnAdd.addActionListener(e -> addRecord());

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(120, 280, 80, 25);
        frame.getContentPane().add(btnUpdate);
        btnUpdate.addActionListener(e -> updateRecord());

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(220, 280, 80, 25);
        frame.getContentPane().add(btnDelete);
        btnDelete.addActionListener(e -> deleteRecord());

        JButton btnView = new JButton("View");
        btnView.setBounds(320, 280, 80, 25);
        frame.getContentPane().add(btnView);
        btnView.addActionListener(e -> viewRecord());
    }

    private void loadTableFields() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        switch (selectedTable) {
            case "Buildings":
                setFields(new String[]{"BuildingID", "Name", "LocationLat", "LocationLong", "Address", "Floors"});
                break;
            case "Departments":
                setFields(new String[]{"DepartmentID", "Name", "BuildingID", "ContactInfo", "Head"});
                break;
            case "Facilities":
                setFields(new String[]{"FacilityID", "Name", "LocationLat", "LocationLong", "Description", "Type"});
                break;
            case "POIs":
                setFields(new String[]{"POIID", "Name", "LocationLat", "LocationLong", "Description"});
                break;
            case "Paths":
                setFields(new String[]{"PathID", "StartLocationLat", "StartLocationLong", "EndLocationLat", "EndLocationLong", "Distance", "Time", "Description"});
                break;
            case "Users":
                setFields(new String[]{"UserID", "Name", "Email", "Role", "LastKnownLocationLat", "LastKnownLocationLong"});
                break;
            case "Events":
                setFields(new String[]{"EventID", "Title", "Description", "Location", "EventDate", "EventTime", "Organizer"});
                break;
        }
    }

    private void setFields(String[] fieldNames) {
        for (int i = 0; i < 6; i++) {
            if (i < fieldNames.length) {
                labels[i].setText(fieldNames[i]);
                labels[i].setVisible(true);
                textFields[i].setVisible(true);
            } else {
                labels[i].setVisible(false);
                textFields[i].setVisible(false);
            }
        }
    }

    private void addRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "INSERT INTO Buildings (BuildingID, Name, LocationLat, LocationLong, Address, Floors) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setInt(6, Integer.parseInt(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "INSERT INTO Departments (DepartmentID, Name, BuildingID, ContactInfo, Head) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setInt(3, Integer.parseInt(textFields[2].getText()));
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "INSERT INTO Facilities (FacilityID, Name, LocationLat, LocationLong, Description, Type) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setString(6, textFields[5].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "INSERT INTO POIs (POIID, Name, LocationLat, LocationLong, Description) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "INSERT INTO Paths (PathID, StartLocationLat, StartLocationLong, EndLocationLat, EndLocationLong, Distance, Time, Description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setFloat(2, Float.parseFloat(textFields[1].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(7, Integer.parseInt(textFields[6].getText()));
                        pstmt.setString(8, textFields[7].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "INSERT INTO Users (UserID, Name, Email, Role, LastKnownLocationLat, LastKnownLocationLong) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "INSERT INTO Events (EventID, Title, Description, Location, EventDate, EventTime, Organizer) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setDate(5, Date.valueOf(textFields[4].getText()));
                        pstmt.setTime(6, Time.valueOf(textFields[5].getText()));
                        pstmt.setString(7, textFields[6].getText());
                        pstmt.executeUpdate();
                    }
                    break;
            }
            JOptionPane.showMessageDialog(frame, selectedTable + " record added successfully.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding record: " + ex.getMessage());
        }
    }

    private void updateRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "UPDATE Buildings SET Name = ?, LocationLat = ?, LocationLong = ?, Address = ?, Floors = ? WHERE BuildingID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "UPDATE Departments SET Name = ?, BuildingID = ?, ContactInfo = ?, Head = ? WHERE DepartmentID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setInt(2, Integer.parseInt(textFields[2].getText()));
                        pstmt.setString(3, textFields[3].getText());
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "UPDATE Facilities SET Name = ?, LocationLat = ?, LocationLong = ?, Description = ?, Type = ? WHERE FacilityID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setString(5, textFields[5].getText());
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "UPDATE POIs SET Name = ?, LocationLat = ?, LocationLong = ?, Description = ? WHERE POIID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(4, textFields[4].getText());
                        pstmt.setInt(5, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "UPDATE Paths SET StartLocationLat = ?, StartLocationLong = ?, EndLocationLat = ?, EndLocationLong = ?, Distance = ?, Time = ?, Description = ? WHERE PathID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setFloat(1, Float.parseFloat(textFields[1].getText()));
                        pstmt.setFloat(2, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[3].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[6].getText()));
                        pstmt.setString(7, textFields[7].getText());
                        pstmt.setInt(8, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "UPDATE Users SET Name = ?, Email = ?, Role = ?, LastKnownLocationLat = ?, LastKnownLocationLong = ? WHERE UserID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setString(2, textFields[2].getText());
                        pstmt.setString(3, textFields[3].getText());
                        pstmt.setFloat(4, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(6, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "UPDATE Events SET Title = ?, Description = ?, Location = ?, EventDate = ?, EventTime = ?, Organizer = ? WHERE EventID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, textFields[1].getText());
                        pstmt.setString(2, textFields[2].getText());
                        pstmt.setString(3, textFields[3].getText());
                        pstmt.setDate(4, Date.valueOf(textFields[4].getText()));
                        pstmt.setTime(5, Time.valueOf(textFields[5].getText()));
                        pstmt.setString(6, textFields[6].getText());
                        pstmt.setInt(7, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
            }
            JOptionPane.showMessageDialog(frame, selectedTable + " record updated successfully.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error updating record: " + ex.getMessage());
        }
    }

    private void deleteRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "DELETE FROM Buildings WHERE BuildingID = ?";
                    break;
                case "Departments":
                    sql = "DELETE FROM Departments WHERE DepartmentID = ?";
                    break;
                case "Facilities":
                    sql = "DELETE FROM Facilities WHERE FacilityID = ?";
                    break;
                case "POIs":
                    sql = "DELETE FROM POIs WHERE POIID = ?";
                    break;
                case "Paths":
                    sql = "DELETE FROM Paths WHERE PathID = ?";
                    break;
                case "Users":
                    sql = "DELETE FROM Users WHERE UserID = ?";
                    break;
                case "Events":
                    sql = "DELETE FROM Events WHERE EventID = ?";
                    break;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                pstmt.executeUpdate();
                JOptionPane.showMessageDialog(frame, selectedTable + " record deleted successfully.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error deleting record: " + ex.getMessage());
        }
    }

    private void viewRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "";
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "SELECT * FROM Buildings WHERE BuildingID = ?";
                    break;
                case "Departments":
                    sql = "SELECT * FROM Departments WHERE DepartmentID = ?";
                    break;
                case "Facilities":
                    sql = "SELECT * FROM Facilities WHERE FacilityID = ?";
                    break;
                case "POIs":
                    sql = "SELECT * FROM POIs WHERE POIID = ?";
                    break;
                case "Paths":
                    sql = "SELECT * FROM Paths WHERE PathID = ?";
                    break;
                case "Users":
                    sql = "SELECT * FROM Users WHERE UserID = ?";
                    break;
                case "Events":
                    sql = "SELECT * FROM Events WHERE EventID = ?";
                    break;
            }
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    for (int i = 0; i < textFields.length; i++) {
                        textFields[i].setText(rs.getString(i + 1));
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "No record found.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error viewing record: " + ex.getMessage());
        }
    }
}
