







import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class javac{
    private static final String DB_URL = "jdbc:mysql://localhost:3306/campus1";
    private static final String USER = "root";  // Use the new user
    private static final String PASS = "Soumya@1411";  // Use the new user's password

    private JFrame frame;
    private JComboBox<String> tableComboBox;
    private JTextField[] textFields;
    private JButton addButton, updateButton, deleteButton, viewButton, searchButton;
    private JTextField searchField;
    private JComboBox<String> searchTypeComboBox;
    private JTextArea resultArea;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CampusNavigationSystem::new);
    }

    public CampusNavigationSystem() {
        frame = new JFrame("Campus Navigation System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(new BorderLayout());

        String[] tables = {"Buildings", "Departments", "Facilities", "POIs", "Paths", "Users", "Events"};
        tableComboBox = new JComboBox<>(tables);
        tableComboBox.addActionListener(e -> loadTableFields());

        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Select Table:"));
        topPanel.add(tableComboBox);

        JPanel centerPanel = new JPanel(new GridLayout(0, 2));
        textFields = new JTextField[8];
        for (int i = 0; i < textFields.length; i++) {
            centerPanel.add(new JLabel("Field " + (i + 1)));
            textFields[i] = new JTextField();
            centerPanel.add(textFields[i]);
        }

        JPanel bottomPanel = new JPanel();
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        viewButton = new JButton("View");
        searchButton = new JButton("Search");

        addButton.addActionListener(e -> addRecord());
        updateButton.addActionListener(e -> updateRecord());
        deleteButton.addActionListener(e -> deleteRecord());
        viewButton.addActionListener(e -> viewRecord());
        searchButton.addActionListener(e -> searchBuilding());

        bottomPanel.add(addButton);
        bottomPanel.add(updateButton);
        bottomPanel.add(deleteButton);
        bottomPanel.add(viewButton);
        bottomPanel.add(searchButton);

        JPanel searchPanel = new JPanel();
        searchField = new JTextField(10);
        String[] searchTypes = {"Building ID", "Building Name"};
        searchTypeComboBox = new JComboBox<>(searchTypes);
        searchPanel.add(new JLabel("Search Building By:"));
        searchPanel.add(searchTypeComboBox);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);

        resultArea = new JTextArea(10, 50);
        resultArea.setEditable(false);

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(centerPanel, BorderLayout.CENTER);
        frame.add(bottomPanel, BorderLayout.SOUTH);
        frame.add(searchPanel, BorderLayout.WEST);
        frame.add(new JScrollPane(resultArea), BorderLayout.EAST);

        frame.setVisible(true);
        loadTableFields();
    }

    private void loadTableFields() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String[] fieldNames;
        switch (selectedTable) {
            case "Buildings":
                fieldNames = new String[]{"BuildingID", "Name", "LocationLat", "LocationLong", "Address", "Floors"};
                break;
            case "Departments":
                fieldNames = new String[]{"DepartmentID", "Name", "BuildingID", "ContactInfo", "Head"};
                break;
            case "Facilities":
                fieldNames = new String[]{"FacilityID", "Name", "LocationLat", "LocationLong", "Description", "Type"};
                break;
            case "POIs":
                fieldNames = new String[]{"POIID", "Name", "LocationLat", "LocationLong", "Description"};
                break;
            case "Paths":
                fieldNames = new String[]{"PathID", "StartLocationLat", "StartLocationLong", "EndLocationLat", "EndLocationLong", "Distance", "Time", "Description"};
                break;
            case "Users":
                fieldNames = new String[]{"UserID", "Name", "Email", "Role", "LastKnownLocationLat", "LastKnownLocationLong"};
                break;
            case "Events":
                fieldNames = new String[]{"EventID", "Title", "Description", "Location", "EventDate", "EventTime", "Organizer"};
                break;
            default:
                fieldNames = new String[]{};
        }

        for (int i = 0; i < textFields.length; i++) {
            if (i < fieldNames.length) {
                textFields[i].setVisible(true);
                textFields[i].setText("");
                ((JLabel) ((Container) textFields[i].getParent()).getComponent(i * 2)).setText(fieldNames[i]);
            } else {
                textFields[i].setVisible(false);
                ((JLabel) ((Container) textFields[i].getParent()).getComponent(i * 2)).setText("");
            }
        }
    }

    private void addRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "INSERT INTO Buildings (BuildingID, Name, LocationLat, LocationLong, Address, Floors) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setInt(6, Integer.parseInt(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "INSERT INTO Departments (DepartmentID, Name, BuildingID, ContactInfo, Head) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setInt(3, Integer.parseInt(textFields[2].getText()));
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "INSERT INTO Facilities (FacilityID, Name, LocationLat, LocationLong, Description, Type) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.setString(6, textFields[5].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "INSERT INTO POIs (POIID, Name, LocationLat, LocationLong, Description) VALUES (?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setString(5, textFields[4].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "INSERT INTO Paths (PathID, StartLocationLat, StartLocationLong, EndLocationLat, EndLocationLong, Distance, Time, Description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setFloat(2, Float.parseFloat(textFields[1].getText()));
                        pstmt.setFloat(3, Float.parseFloat(textFields[2].getText()));
                        pstmt.setFloat(4, Float.parseFloat(textFields[3].getText()));
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.setInt(7, Integer.parseInt(textFields[6].getText()));
                        pstmt.setString(8, textFields[7].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "INSERT INTO Users (UserID, Name, Email, Role, LastKnownLocationLat, LastKnownLocationLong) VALUES (?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setString(4, textFields[3].getText());
                        pstmt.setFloat(5, Float.parseFloat(textFields[4].getText()));
                        pstmt.setFloat(6, Float.parseFloat(textFields[5].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "INSERT INTO Events (EventID, Title, Description, Location, EventDate, EventTime, Organizer) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.setString(2, textFields[1].getText());
                        pstmt.setString(3, textFields[2].getText());
                        pstmt.setInt(4, Integer.parseInt(textFields[3].getText()));
                        pstmt.setDate(5, Date.valueOf(textFields[4].getText()));
                        pstmt.setTime(6, Time.valueOf(textFields[5].getText()));
                        pstmt.setString(7, textFields[6].getText());
                        pstmt.executeUpdate();
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            JOptionPane.showMessageDialog(frame, "Record added successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error adding record: " + ex.getMessage());
        }
    }

    private void updateRecord() {
        // Implementation similar to addRecord() but using an UPDATE SQL statement
    }

    private void deleteRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            switch (selectedTable) {
                case "Buildings":
                    sql = "DELETE FROM Buildings WHERE BuildingID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Departments":
                    sql = "DELETE FROM Departments WHERE DepartmentID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Facilities":
                    sql = "DELETE FROM Facilities WHERE FacilityID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "POIs":
                    sql = "DELETE FROM POIs WHERE POIID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Paths":
                    sql = "DELETE FROM Paths WHERE PathID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Users":
                    sql = "DELETE FROM Users WHERE UserID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                case "Events":
                    sql = "DELETE FROM Events WHERE EventID = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setInt(1, Integer.parseInt(textFields[0].getText()));
                        pstmt.executeUpdate();
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Unknown table selected");
            }
            JOptionPane.showMessageDialog(frame, "Record deleted successfully");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error deleting record: " + ex.getMessage());
        }
    }

    private void viewRecord() {
        String selectedTable = (String) tableComboBox.getSelectedItem();
        String sql = "SELECT * FROM " + selectedTable;
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            StringBuilder sb = new StringBuilder();
            int columnCount = rs.getMetaData().getColumnCount();
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    sb.append(rs.getString(i)).append(" ");
                }
                sb.append("\n");
            }
            resultArea.setText(sb.toString());
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error viewing records: " + ex.getMessage());
        }
    }

    private void searchBuilding() {
        String searchType = (String) searchTypeComboBox.getSelectedItem();
        String searchValue = searchField.getText();
        String sql;
        if (searchType.equals("Building ID")) {
            sql = "SELECT * FROM Buildings WHERE BuildingID = ?";
        } else {
            sql = "SELECT * FROM Buildings WHERE Name = ?";
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            if (searchType.equals("Building ID")) {
                pstmt.setInt(1, Integer.parseInt(searchValue));
            } else {
                pstmt.setString(1, searchValue);
            }

            try (ResultSet rs = pstmt.executeQuery()) {
                StringBuilder sb = new StringBuilder();
                int columnCount = rs.getMetaData().getColumnCount();
                while (rs.next()) {
                    for (int i = 1; i <= columnCount; i++) {
                        sb.append(rs.getString(i)).append(" ");
                    }
                    sb.append("\n");
                }
                resultArea.setText(sb.toString());
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error searching building: " + ex.getMessage());
        }
    }
}

